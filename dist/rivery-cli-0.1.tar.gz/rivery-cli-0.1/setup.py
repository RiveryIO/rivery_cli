from setuptools import setup

setup(
    name='rivery-cli',
    version='0.1',
    py_modules=[
        'rivery_cli'
    ],
    install_requires=[
        'Click',
        "requests",
        "PyYaml",
        "pymongo",
        "jsonschema",
        "jsonschema_extended"
    ],
    entry_points="""
        [console_scripts]
        rivery=base:main
    """
)